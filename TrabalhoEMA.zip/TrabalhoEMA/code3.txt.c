#include<stdio.h>
#include<math.h>

int main(int argc, char *argv[]){
int gaveta=0;
int mexer=1;
 
if (mexer!=0) {
 
if (gaveta!=0) {
gaveta=0;
char* frase="Gaveta fechada";
printf("%s", frase);
}
 else {
gaveta=1;
char* frase1="Gaveta aberta";
printf("%s", frase1);
 }
}
 else {
char* frase2="Melhor deixar do jeito que ta mesmo";
printf("%s", frase2);
 }

}
