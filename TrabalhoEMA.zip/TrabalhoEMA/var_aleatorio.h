#ifndef _VAR_ALEATORIO_H_
#define _VAR_ALEATORIO_H_

extern char *nome();

#endif
